#!/bin/bash

docker exec -ti jenkins cat /var/jenkins_home/secrets/initialAdminPassword